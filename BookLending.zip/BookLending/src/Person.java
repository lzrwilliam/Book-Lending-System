public abstract class Person {
    protected String name;
    protected String surname;

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }
}
