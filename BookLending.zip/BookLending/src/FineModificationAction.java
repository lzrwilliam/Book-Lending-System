public enum FineModificationAction {
    UPDATE_AMOUNT,
    UPDATE_PAID_STATUS
}