public enum LoanStatus {
    ACTIVE,
    RETURNED
}
